package com.course.cqrs.proto_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProtoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProtoApiApplication.class, args);
	}

}
