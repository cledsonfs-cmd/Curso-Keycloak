package com.course.cqrs.proto_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProtoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
